export default function Page() {
  return (
    <div style={{padding: 20}}>
      <h1>שלום 👋</h1>
      <p>האתר עלה! נתחיל להוסיף פיצ׳רים אחרי שהדיפלוי יעבור.</p>
    </div>
  );
}
